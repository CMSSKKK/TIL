package spring;

public class WrongPasswordException extends RuntimeException {

}
